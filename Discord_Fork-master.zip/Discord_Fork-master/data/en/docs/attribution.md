---
pagename: Attributions
description: List of open source projects which help make Discord_Fork great
---

# Open Source
Terminal.ink is commited to open source, by making all source code open to allow people to contribute and give feedback to code.

This website uses magic technology from the open source community.

[View all dependencies here](https://github.com/Terminal/Discord_Fork/network/dependencies)
