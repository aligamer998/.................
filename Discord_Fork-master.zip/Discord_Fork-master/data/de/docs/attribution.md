---
pagename: Attributions
description: List of open source projects which help make Discord_Fork great
---

```json
{
  "flat": "^4.1.0",
  "gatsby": "next",
  "gatsby-image": "next",
  "gatsby-link": "next",
  "gatsby-plugin-catch-links": "^2.0.2",
  "gatsby-plugin-netlify": "^2.0.0",
  "gatsby-plugin-offline": "^2.0.5",
  "gatsby-plugin-react-helmet": "next",
  "gatsby-plugin-sass": "next",
  "gatsby-plugin-sharp": "next",
  "gatsby-remark-external-links": "0.0.4",
  "gatsby-source-filesystem": "next",
  "gatsby-transformer-remark": "next",
  "gatsby-transformer-sharp": "next",
  "js-yaml": "^3.12.0",
  "mkdirp": "^0.5.1",
  "mustache": "^3.0.0",
  "node-sass": "^4.9.3",
  "react": "^16.5.1",
  "react-dom": "^16.5.1",
  "react-helmet": "^5.2.0",
  "react-intl": "^2.6.0",
  "react-monaco-editor": "^0.18.0",
  "request": "^2.88.0",
  "rimraf": "^2.6.2",
  "sharp": "^0.20.8",
  "word-wrap": "^1.2.3"
}
```
